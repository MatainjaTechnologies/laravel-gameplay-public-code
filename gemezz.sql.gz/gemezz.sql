-- Adminer 4.8.1 MySQL 8.0.26-0ubuntu0.20.04.2 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1,	'Admin',	'admin@gmail.com',	'$2y$10$4MJcWWuF2PleL8.y3T5UMuNoNeleCj8q23wB0i4yDTxtfoxXsdKma',	NULL,	NULL);

DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `game_id` int unsigned NOT NULL,
  `position` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `banners_game_id_index` (`game_id`),
  CONSTRAINT `banners_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `icon` longtext COLLATE utf8mb4_unicode_ci,
  `banner` longtext COLLATE utf8mb4_unicode_ci,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `uuid`, `name`, `slug`, `type`, `status`, `created_at`, `updated_at`, `icon`, `banner`, `is_deleted`) VALUES
(1,	'rgrgr545454grgrg5rgr5g45',	'Top Chart',	'top_chart',	'game',	0,	'2021-08-31 14:57:10',	'2021-09-10 07:37:18',	'rgrgr545454grgrg5rgr5g45_10092021073718_icon_image.png',	NULL,	NULL),
(2,	'0258e3cb-3a11-4f6a-8b9c-85c20614b4a5',	'Puzzle',	'puzzle',	'game',	1,	'2021-09-02 18:44:43',	'2021-09-10 07:37:51',	'0258e3cb-3a11-4f6a-8b9c-85c20614b4a5_08092021145058_icon_image.png',	NULL,	NULL),
(3,	'0ee96e93-4c2e-49a2-9012-9f717993aeeb',	'Arcade',	'arcade',	'game',	1,	'2021-09-02 18:44:53',	'2021-09-10 07:39:20',	'0ee96e93-4c2e-49a2-9012-9f717993aeeb_10092021073920_icon_image.png',	NULL,	NULL),
(4,	'7c9bccc1-2619-4f81-aff9-3901043e494a',	'Racing',	'racing',	'game',	1,	'2021-09-03 08:20:22',	'2021-09-10 07:41:01',	'7c9bccc1-2619-4f81-aff9-3901043e494a_10092021074101_icon_image.png',	NULL,	NULL),
(5,	'92473d10-b7dd-45e5-aa99-9d6de390465d',	'Sport',	'sport',	'game',	1,	'2021-09-03 08:20:31',	'2021-09-10 07:41:39',	'92473d10-b7dd-45e5-aa99-9d6de390465d_10092021074139_icon_image.png',	NULL,	NULL),
(6,	'0ca33133-840f-4d52-bf29-1f0c10b5154c',	'Card',	'card',	'game',	1,	'2021-09-03 08:20:36',	'2021-09-10 07:43:04',	'0ca33133-840f-4d52-bf29-1f0c10b5154c_10092021074304_icon_image.png',	NULL,	NULL),
(7,	'6263b5db-32b1-4405-8a78-d6658f85344e',	'Shooting',	'shooting',	'game',	1,	'2021-09-03 08:20:44',	'2021-09-10 07:43:42',	'6263b5db-32b1-4405-8a78-d6658f85344e_10092021074342_icon_image.png',	NULL,	NULL),
(8,	'52872af1-ff02-45cc-9d11-d93f75f96ce3',	'Strategy',	'strategy',	'game',	1,	'2021-09-03 08:20:55',	'2021-09-10 07:44:51',	'52872af1-ff02-45cc-9d11-d93f75f96ce3_10092021074451_icon_image.png',	NULL,	NULL),
(9,	'e998134b-0423-46cf-9eca-d34ee7607dcb',	'Platformer',	'platformer',	'game',	1,	'2021-09-06 14:19:31',	'2021-09-10 07:45:55',	'e998134b-0423-46cf-9eca-d34ee7607dcb_10092021074555_icon_image.png',	NULL,	NULL),
(10,	'e35ee3ee-8e9f-44d2-935e-27086319997a',	'PVP',	'pvp',	'game',	1,	'2021-09-10 07:46:25',	'2021-09-10 07:46:25',	'e35ee3ee-8e9f-44d2-935e-27086319997a_10092021074625_icon_image.png',	NULL,	NULL),
(11,	'80a8a2fd-c1ef-4194-9572-59d8bbab9906',	'asdf',	'asdf',	'game',	1,	'2021-09-24 11:43:02',	'2021-09-24 11:43:22',	'80a8a2fd-c1ef-4194-9572-59d8bbab9906_24092021114302_icon_image.png',	'80a8a2fd-c1ef-4194-9572-59d8bbab9906_24092021114302_banner_image.png',	1);

DROP TABLE IF EXISTS `competitions`;
CREATE TABLE `competitions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_competitiongame` bigint NOT NULL,
  `competition_type` int NOT NULL,
  `prize_image1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prize_coins1` int DEFAULT NULL,
  `prize_image2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prize_coins2` int DEFAULT NULL,
  `prize_image3` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prize_coins3` int DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `banner_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `competitions` (`id`, `id_competitiongame`, `competition_type`, `prize_image1`, `prize_coins1`, `prize_image2`, `prize_coins2`, `prize_image3`, `prize_coins3`, `start_date`, `end_date`, `created_at`, `updated_at`, `banner_image`, `is_deleted`) VALUES
(2,	33,	1,	'icon_1509525119_1509525119.jpg',	40,	'icon_1509525119_1509525119.jpg',	24,	'icon_1509525119_1509525119.jpg',	20,	'2021-09-13',	'2021-09-13',	'2021-09-13 05:35:38',	'2021-09-16 05:56:56',	'banner_1526471685_1526471685.jpg',	NULL),
(3,	29,	1,	'icon_1494932411_1494932411.gif',	35,	'icon_1494932411_1494932411.gif',	25,	'icon_1494932411_1494932411.gif',	20,	'2021-09-14',	'2021-09-14',	'2021-09-13 05:42:06',	'2021-09-13 05:42:06',	'icon_1494932411_1494932411.gif',	NULL),
(4,	24,	2,	'icon_1509523372_1509523372.jpg',	34,	'icon_1509523372_1509523372.jpg',	30,	'icon_1509523372_1509523372.jpg',	20,	'2021-09-13',	'2021-09-20',	'2021-09-13 05:44:21',	'2021-09-13 05:44:21',	'icon_1509523372_1509523372.jpg',	NULL),
(5,	23,	1,	'icon_1508831707_1505457259.jpg',	40,	'icon_1508831707_1505457259.jpg',	25,	'icon_1508831707_1505457259.jpg',	25,	'2021-09-15',	'2021-09-15',	'2021-09-13 05:46:18',	'2021-09-13 12:32:16',	'banner_1505457259_1505457259.png',	NULL),
(6,	26,	1,	'icon_1526471465_1526471465.png',	36,	'icon_1526471465_1526471465.png',	24,	'icon_1526471465_1526471465.png',	18,	'2021-09-15',	'2021-09-15',	'2021-09-13 05:47:55',	'2021-09-13 05:47:55',	'icon_1526471465_1526471465.png',	NULL),
(7,	27,	2,	'icon_1527135572_1527135572.png',	40,	'icon_1527135572_1527135572.png',	30,	'icon_1527135572_1527135572.png',	25,	'2021-09-14',	'2021-09-21',	'2021-09-13 05:49:09',	'2021-09-13 05:49:09',	'icon_1527135572_1527135572.png',	NULL),
(8,	32,	1,	'icon_1506335191_1506335191.png',	24,	'icon_1506335191_1506335191.png',	18,	'icon_1506335191_1506335191.png',	15,	'2021-09-20',	'2021-09-20',	'2021-09-13 05:50:26',	'2021-09-13 05:50:26',	'icon_1506335191_1506335191.png',	NULL),
(9,	34,	3,	'icon_1508831742_1505460158.jpg',	35,	'icon_1508831742_1505460158.jpg',	25,	'icon_1508831742_1505460158.jpg',	15,	'2021-09-14',	'2021-10-06',	'2021-09-13 05:55:36',	'2021-09-13 05:55:36',	'icon_1508831742_1505460158.jpg',	NULL),
(10,	36,	3,	'icon_1527071188_1527071188.png',	40,	'icon_1527071188_1527071188.png',	20,	'icon_1527071188_1527071188.png',	15,	'2021-09-15',	'2021-10-08',	'2021-09-13 05:56:53',	'2021-09-13 05:56:53',	'icon_1527071188_1527071188.png',	NULL),
(11,	37,	2,	'icon_1604983170_1603885615.png',	45,	'icon_1604983170_1603885615.png',	25,	'icon_1604983170_1603885615.png',	20,	'2021-09-15',	'2021-09-22',	'2021-09-13 05:59:48',	'2021-09-13 05:59:48',	'icon_1604983170_1603885615.png',	NULL),
(13,	28,	2,	'tetris.png',	20,	'tetris.png',	15,	'tetris.png',	10,	'2021-09-28',	'2021-09-28',	'2021-09-16 07:05:13',	'2021-09-22 05:55:26',	'tetris.png',	1),
(16,	65,	1,	'icon_1627459150_1548410539.jpg',	20,	'icon_1627459150_1548410539.jpg',	12,	'icon_1627459150_1548410539.jpg',	10,	'2021-09-21',	'2021-09-21',	'2021-09-16 08:32:20',	'2021-09-21 12:00:11',	'icon_1627459150_1548410539.jpg',	NULL),
(17,	66,	2,	'banner_1608296741_1608209210.png',	25,	'banner_1608296741_1608209210.png',	18,	'banner_1608296741_1608209210.png',	12,	'2021-09-17',	'2021-09-24',	'2021-09-16 08:40:32',	'2021-09-16 08:40:32',	'banner_1608296741_1608209210.png',	NULL),
(18,	67,	3,	'banner_1618555719_1618555719.png',	30,	'banner_1618555719_1618555719.png',	20,	'banner_1618555719_1618555719.png',	15,	'2021-09-16',	'2021-10-07',	'2021-09-16 08:50:29',	'2021-09-16 08:50:29',	'banner_1618555719_1618555719.png',	NULL),
(19,	68,	3,	'icon_1505726548_1505726548.jpg',	20,	'icon_1505726548_1505726548.jpg',	15,	'icon_1505726548_1505726548.jpg',	10,	'2021-11-08',	'2021-11-08',	'2021-09-16 11:49:19',	'2021-10-07 14:25:31',	'icon_1505726548_1505726548.jpg',	NULL),
(20,	69,	2,	'banner_1621600285_1616489478.png',	45,	'banner_1621600285_1616489478.png',	30,	'banner_1621600285_1616489478.png',	25,	'2021-09-23',	'2021-09-23',	'2021-09-16 12:10:06',	'2021-10-07 14:27:00',	'banner_1621600285_1616489478.png',	NULL),
(21,	70,	1,	'banner_1494929986_1494929986.png',	20,	'banner_1494929986_1494929986.png',	12,	'banner_1494929986_1494929986.png',	10,	'2021-10-07',	'2021-10-07',	'2021-09-16 13:43:15',	'2021-10-07 14:47:14',	'banner_1524578725_1524578725.png',	NULL),
(22,	28,	1,	'icon_1616159231_1509523958.png',	30,	'icon_1616159231_1509523958.png',	20,	'icon_1616159231_1509523958.png',	10,	'2021-10-07',	'2021-10-07',	'2021-09-22 05:58:12',	'2021-10-07 14:15:13',	'icon_1616159231_1509523958.png',	NULL),
(23,	73,	2,	'flappy_color_birds.jpg',	30,	'flappy_color_birds.jpg',	20,	'flappy_color_birds.jpg',	15,	'2021-10-08',	'2021-10-15',	'2021-10-08 15:20:22',	'2021-10-08 15:20:22',	'flappy_color_birds.jpg',	NULL);

DROP TABLE IF EXISTS `domains`;
CREATE TABLE `domains` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `source_path` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `destination_path` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `daily_subs_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subscribe_notify_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `unsubscribe_notify_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `weekly_subs_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `monthly_subs_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `yearly_subs_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `renew_subs_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domains_domian_name_unique` (`domain_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `domains` (`id`, `domain_name`, `logo`, `source_path`, `destination_path`, `daily_subs_url`, `subscribe_notify_url`, `unsubscribe_notify_url`, `status`, `created_at`, `updated_at`, `is_deleted`, `weekly_subs_url`, `monthly_subs_url`, `yearly_subs_url`, `renew_subs_url`) VALUES
(1,	'gemezz.code-dev.in',	'1_22092021134201_logo_image.png',	'1',	'1',	'http://103.77.79.133:11002/gemday/?msisdn=6698756',	'http://gemezz.code-dev.in/subscription/notify?msisdn=1234567890&package=daily&trxid=99660088&event=reg',	'https://dtac.th.gemezz.mobi/index.php/subscription/Unsubscribe/unsubs?msisdn=200452301&event=unreg',	1,	'2021-09-22 13:42:01',	'2021-09-22 13:42:01',	NULL,	'http://103.77.79.133:11002/gemweek/?msisdn=6698756',	'http://103.77.79.133:11002/gemonthly/?msisdn=6698756',	'http://103.77.79.133:11002/gemannual/?msisdn=6698756',	'https://dtac.th.gemezz.mobi/subscription/Renewal/renewal?msisdn=1234567890&package=yearly&trxid=99660088&event=renewal'),
(2,	'localhost',	'2_27092021050939_logo_image.png',	'localhost',	'localhost',	'localhost',	'localhost',	'localhost',	1,	'2021-09-27 05:09:39',	'2021-09-29 06:22:37',	1,	'localhost',	'localhost',	'localhost',	'localhost');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `games`;
CREATE TABLE `games` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rule` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int unsigned NOT NULL,
  `coin` bigint NOT NULL,
  `version` bigint NOT NULL,
  `is_home` tinyint(1) NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cover_image` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `is_top_game` int DEFAULT NULL,
  `view` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `games_category_id_index` (`category_id`),
  KEY `uuid` (`uuid`),
  CONSTRAINT `games_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `games` (`id`, `uuid`, `name`, `description`, `rule`, `category_id`, `coin`, `version`, `is_home`, `image`, `cover_image`, `url`, `created_at`, `updated_at`, `is_deleted`, `is_top_game`, `view`) VALUES
(12,	'0d05877f-15e2-4424-818c-00b311b90b5b',	'Floppy Fly',	'Floppy Fly is an test game for testing purpose',	'Floppy Fly is an test game for testing purpose and it\'s don\'t have any rule',	1,	100,	1,	0,	'a:1:{i:0;s:28:\"12_09092021113332_game_0.jpg\";}',	'12_09092021125550_cover_image.jpg',	'NULL',	'2021-09-09 11:33:32',	'2021-09-09 12:55:50',	NULL,	0,	NULL),
(15,	'dd16c0c0-a24b-4150-9fa6-ce1f1d2c7877',	'Circle Runner',	'Circle Runner description',	'Circle Runner game rule',	1,	100,	1,	0,	'a:1:{i:0;s:28:\"15_09092021131150_game_0.jpg\";}',	'15_09092021131150_cover_image.jpg',	'NULL',	'2021-09-09 13:11:50',	'2021-09-09 13:11:50',	NULL,	0,	NULL),
(17,	'72ee397b-05e4-4ef5-9b79-9e809aa7241e',	'Chase Racing Cars',	'Chase Racing Cars description',	'Chase Racing Cars game rule',	1,	100,	1,	0,	'a:1:{i:0;s:28:\"17_09092021132419_game_0.jpg\";}',	'17_09092021132419_cover_image.jpg',	'NULL',	'2021-09-09 13:24:19',	'2021-09-09 13:24:19',	NULL,	0,	NULL),
(19,	'97d77970-6b4e-42e2-8863-cd21244160af',	'Sky Warrior',	'Sky Warrior is an HTML game.',	'Sky Warrior game rule will be published later.',	8,	10,	1,	0,	'a:1:{i:0;s:28:\"19_10092021083613_game_0.jpg\";}',	'19_10092021083613_cover_image.jpg',	'NULL',	'2021-09-10 08:36:13',	'2021-09-20 15:06:21',	NULL,	0,	NULL),
(20,	'783d0f85-020b-4d05-8334-8c458a4477df',	'Sky Knight',	'Sky Knight ia a HTML game.',	'Sky Knight rule will be published later.',	1,	10,	1,	0,	'a:1:{i:0;s:28:\"20_10092021084057_game_0.jpg\";}',	'20_10092021084057_cover_image.jpg',	'NULL',	'2021-09-10 08:40:56',	'2021-09-10 08:40:57',	NULL,	0,	NULL),
(21,	'93d60744-94b8-45a7-b252-f881318cfcec',	'Cyber racer',	'Cyber racer is an HTML game.',	'Cyber racer game rule will be published later.',	1,	10,	1,	0,	'a:1:{i:0;s:28:\"21_10092021085016_game_0.jpg\";}',	'21_10092021085016_cover_image.jpg',	'NULL',	'2021-09-10 08:50:16',	'2021-09-10 08:50:16',	NULL,	0,	NULL),
(22,	'379f84ff-63bc-4034-bc34-5b6955e626ac',	'Driver Highway',	'Driver Highway isan HTML game.',	'Driver Highway game rule will be published later.',	1,	10,	1,	0,	'a:1:{i:0;s:28:\"22_10092021085611_game_0.jpg\";}',	'22_10092021085611_cover_image.jpg',	'NULL',	'2021-09-10 08:56:11',	'2021-09-21 09:06:02',	1,	0,	NULL),
(23,	'99fc38d2-16e6-4cbb-b5e6-93c40f4b295b',	'Jewel Bubbles 3',	'Jewel Bubbles 3 is an html game.',	'Jewel Bubbles 3 game rules will be published later.',	2,	10,	1,	0,	'a:2:{i:0;s:28:\"23_10092021110353_game_0.jpg\";i:1;s:28:\"23_21092021055522_game_0.png\";}',	'23_21092021055522_cover_image.png',	'NULL',	'2021-09-10 11:03:53',	'2021-10-22 09:42:07',	NULL,	1,	37),
(24,	'2ade8d31-671c-4e72-9932-c64f6fd560c6',	'Plumber',	'Plumber is an HTML game',	'Plumber game rule will bve published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"24_10092021131048_game_0.jpg\";}',	'24_10092021131048_cover_image.jpg',	'NULL',	'2021-09-10 13:10:48',	'2021-10-24 19:22:25',	NULL,	1,	14),
(25,	'1ff7d543-f4ff-407b-89fe-351503febc6b',	'Ball in the Cup',	'Ball in the Cup is an HTML game.',	'Ball in the Cup game rule will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"25_10092021134725_game_0.jpg\";}',	'25_10092021134725_cover_image.jpg',	'NULL',	'2021-09-10 13:47:25',	'2021-10-24 19:21:59',	NULL,	1,	9),
(26,	'a10aa74c-a8bd-4ed5-a11a-4cf51f6b243a',	'Dentist Doctor Teeth',	'Dentist Doctor Teeth is an HTML game.',	'Dentist Doctor Teeth game rules will be published later',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"26_10092021135248_game_0.png\";}',	'26_10092021135248_cover_image.png',	'NULL',	'2021-09-10 13:52:48',	'2021-10-11 13:00:55',	NULL,	1,	3),
(27,	'd478ecfa-20fe-48a6-bfd7-d2569446b812',	'Ludo board game',	'Ludo board game is an HTML game',	'Ludo board game rules will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"27_10092021140944_game_0.png\";}',	'27_10092021140944_cover_image.png',	'NULL',	'2021-09-10 14:09:44',	'2021-10-22 09:42:11',	NULL,	1,	18),
(28,	'13337d86-ddc8-43a0-8e1d-cc2c16620a36',	'Tetris',	'Tetris is an HTML game',	'Tetris game rules will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"28_10092021142123_game_0.png\";}',	'28_10092021142123_cover_image.png',	'NULL',	'2021-09-10 14:21:23',	'2021-10-19 08:18:03',	NULL,	1,	28),
(29,	'e55cf92f-4e3f-425c-a920-86ef3df3542f',	'Colored Circle',	'Colored Circle is an HTML game.',	'Colored Circle game rule will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"29_10092021142911_game_0.gif\";}',	'29_10092021142911_cover_image.gif',	'NULL',	'2021-09-10 14:29:11',	'2021-09-13 06:57:40',	NULL,	1,	NULL),
(30,	'8bd783bc-3640-47be-b28a-296daf6bdc19',	'Tower Mania',	'Tower Mania is an HTML game',	'Tower Mania game rule will be published later',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"30_10092021143703_game_0.png\";}',	'30_10092021143703_cover_image.png',	'NULL',	'2021-09-10 14:37:03',	'2021-10-20 07:42:18',	NULL,	1,	4),
(31,	'a00ec72e-f3f2-4787-af7d-f783dc202b3f',	'Artic Pong',	'Artic Pong is an GTML game.',	'Artic Pong games rule will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"31_10092021144043_game_0.png\";}',	'31_10092021144043_cover_image.png',	'NULL',	'2021-09-10 14:40:43',	'2021-09-21 19:04:36',	NULL,	1,	1),
(32,	'91aea1d8-e23d-4be4-b23a-67801067f683',	'Timber Man',	'Timber Man is an HTML game',	'Timber Man game rule willl be published later',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"32_10092021144448_game_0.png\";}',	'32_10092021144448_cover_image.png',	'NULL',	'2021-09-10 14:44:48',	'2021-10-22 06:11:33',	NULL,	1,	9),
(33,	'606ff122-2c17-4498-93d3-3ea6b8667627',	'Ninja Clan',	'Ninja Clan is an HTML game.',	'Ninja Clan game rule will be published later',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"33_10092021144745_game_0.jpg\";}',	'33_10092021144745_cover_image.jpg',	'NULL',	'2021-09-10 14:47:45',	'2021-10-20 07:04:29',	NULL,	1,	6),
(34,	'6f6b883a-3cb3-42a6-a829-ba787d711519',	'Mahjong Master 2',	'Mahjong Master 2 is an HTML game.',	'TMahjong Master 2 game rule will be published later',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"34_10092021145421_game_0.jpg\";}',	'34_10092021145421_cover_image.jpg',	'NULL',	'2021-09-10 14:54:20',	'2021-09-28 10:47:14',	NULL,	1,	1),
(35,	'20b8c157-3b1b-409f-8471-5a3c6443cfe7',	'Treasure Ninja',	'Treasure Ninja is an HTML game.',	'Treasure Ninja game rule will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"35_10092021145918_game_0.jpg\";}',	'35_10092021145918_cover_image.jpg',	'NULL',	'2021-09-10 14:59:18',	'2021-09-21 19:05:01',	NULL,	1,	1),
(36,	'919714ae-0aca-477d-9c40-5d2b94f050b5',	'Freecell Solitaire',	'Freecell Solitaire is an HTML game.',	'Freecell Solitaire  game details will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"36_10092021150641_game_0.png\";}',	'36_10092021150641_cover_image.png',	'NULL',	'2021-09-10 15:06:40',	'2021-10-19 06:14:03',	NULL,	1,	1),
(37,	'52d25d58-0ae2-4fea-9ac7-742d1ad384b2',	'Gravity soccer',	'Gravity soccer is an HTML game.',	'Gravity soccer game rule will be published later.',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"37_10092021151102_game_0.png\";}',	'37_10092021151102_cover_image.png',	'NULL',	'2021-09-10 15:11:02',	'2021-09-13 06:55:30',	NULL,	1,	NULL),
(38,	'214a03f4-5972-439f-b135-95ca40dd7d70',	'football champion',	'football champion is an HTML game',	'football champion game rule will be published later',	2,	10,	1,	0,	'a:1:{i:0;s:28:\"38_10092021151440_game_0.jpg\";}',	'38_10092021151440_cover_image.jpg',	'NULL',	'2021-09-10 15:14:40',	'2021-09-27 06:31:05',	NULL,	1,	2),
(39,	'3676a618-a981-4d52-a315-1d04b3c0acbf',	'Box Jump',	'Box Jump is an HTML game.',	'Box Jump game rule will be published later.',	2,	20,	1,	0,	'a:1:{i:0;s:28:\"39_13092021062646_game_0.gif\";}',	'39_13092021062646_cover_image.gif',	'NULL',	'2021-09-13 06:26:46',	'2021-09-28 10:49:18',	NULL,	1,	2),
(43,	'0c365ae1-97fc-4ecf-8252-310251b76256',	'soccer multiplayers',	'soccer multiplayers is an HTML game.',	'soccer multiplayers game rule will be published later.',	10,	25,	1,	0,	'a:1:{i:0;s:28:\"43_13092021071952_game_0.png\";}',	'43_13092021071952_cover_image.png',	'NULL',	'2021-09-13 07:19:52',	'2021-09-23 14:42:40',	NULL,	1,	4),
(44,	'6a7715b7-3ccf-4205-972e-bdec4726d69b',	'Jun Ken Po Multiplayer',	'Jun Ken Po Multiplayer is an HTML game',	'Jun Ken Po Multiplayer game rule will be published later',	10,	25,	1,	0,	'a:1:{i:0;s:28:\"44_13092021073734_game_0.png\";}',	'44_13092021073734_cover_image.png',	'NULL',	'2021-09-13 07:37:34',	'2021-09-13 07:37:34',	NULL,	0,	NULL),
(45,	'17c7ca28-867b-4a73-af15-6b778d58e611',	'Tic Tac Toe Multiplayer',	'Tic Tac Toe Multiplayer is an HTML game',	'Tic Tac Toe Multiplayer game rule will be published later.',	10,	25,	1,	0,	'a:1:{i:0;s:28:\"45_13092021074309_game_0.jpg\";}',	'45_13092021074309_cover_image.jpg',	'NULL',	'2021-09-13 07:43:09',	'2021-09-13 07:43:09',	NULL,	1,	NULL),
(46,	'c9d708d8-208c-408d-89c6-1057a4a14e26',	'Cyber racer',	'Cyber racer is an HTML game.',	'Cyber racer game rule will be published later',	10,	25,	1,	0,	'a:1:{i:0;s:28:\"46_13092021075924_game_0.jpg\";}',	'46_13092021075924_cover_image.jpg',	'NULL',	'2021-09-13 07:59:23',	'2021-09-13 07:59:24',	NULL,	1,	NULL),
(47,	'4e7069d8-1d61-4e8a-b688-9f4757f75269',	'Driver Highway',	'Driver Highway is an HTML game',	'Driver Highway game rules  will be published later.',	10,	25,	1,	0,	'a:1:{i:0;s:28:\"47_13092021080752_game_0.jpg\";}',	'47_13092021080752_cover_image.jpg',	'NULL',	'2021-09-13 08:07:52',	'2021-09-23 14:35:22',	NULL,	1,	2),
(48,	'76bc9753-03f2-4db3-85b4-f22b8111c01c',	'Two Cars',	'Two Cars is an HTML game',	'Two Cars game rule will be published later.',	4,	10,	1,	0,	'a:1:{i:0;s:28:\"48_13092021081426_game_0.jpg\";}',	'48_13092021081426_cover_image.jpg',	'NULL',	'2021-09-13 08:14:26',	'2021-09-23 19:03:11',	NULL,	1,	2),
(49,	'3820586b-1ec9-45b9-91c1-6ad07a446e06',	'Moto Fury',	'Moto Fury is an HTML game.',	'Moto Fury game rule will be published later',	4,	10,	1,	0,	'a:1:{i:0;s:28:\"49_13092021081809_game_0.jpg\";}',	'49_13092021081809_cover_image.jpg',	'NULL',	'2021-09-13 08:18:09',	'2021-09-13 08:18:09',	NULL,	1,	NULL),
(50,	'bd9f2856-68c0-4461-82f3-7bb687ddfe33',	'Traffic Car',	'Traffic Car is an HTML game',	'Traffic Car game rulke will be published later',	4,	10,	1,	0,	'a:1:{i:0;s:28:\"50_13092021082231_game_0.jpg\";}',	'50_13092021082231_cover_image.jpg',	'NULL',	'2021-09-13 08:22:31',	'2021-09-13 08:22:31',	NULL,	1,	NULL),
(51,	'df99936c-30d2-4c98-b7a0-c60dfae9abac',	'Car Traffic Racing',	'Car Traffic Racing is an HTML game.',	'Car Traffic Racing game rule will be published later.',	4,	10,	1,	0,	'a:1:{i:0;s:28:\"51_13092021082419_game_0.jpg\";}',	'51_13092021082419_cover_image.jpg',	'NULL',	'2021-09-13 08:24:19',	'2021-09-23 19:03:06',	NULL,	1,	1),
(52,	'18dd6eb8-3a9c-4a1e-9222-bc5ee161a979',	'Speedlust Driver',	'Speedlust Driver ia an GTML game.',	'Speedlust Driver game rule will be published later',	4,	10,	1,	0,	'a:1:{i:0;s:28:\"52_13092021082927_game_0.jpg\";}',	'52_13092021082927_cover_image.jpg',	'NULL',	'2021-09-13 08:29:27',	'2021-09-23 19:03:03',	NULL,	1,	1),
(53,	'2dd037b4-d3ab-4461-8446-e49cffb79d78',	'Castle Defense',	'Castle Defense is an HTML game',	'Castle Defense  game rules will be published later',	7,	15,	1,	0,	'a:1:{i:0;s:28:\"53_13092021103427_game_0.png\";}',	'53_13092021103427_cover_image.png',	'NULL',	'2021-09-13 10:34:27',	'2021-10-21 11:14:22',	NULL,	1,	7),
(54,	'b6ed64a4-07e7-42eb-9fd4-7c596e36c334',	'Pixel Shooter',	'Pixel Shooter is an HTML game',	'Pixel Shooter game rule',	4,	15,	1,	0,	'a:1:{i:0;s:28:\"54_13092021105446_game_0.png\";}',	'54_13092021105446_cover_image.png',	'NULL',	'2021-09-13 10:54:46',	'2021-09-13 10:54:46',	NULL,	1,	NULL),
(55,	'8e5bc2df-5c91-4b06-97ee-cde95b6a6664',	'Space Shooter',	'Space Shooter is an HTML game',	'Space Shooter game rule will be published later',	4,	15,	1,	0,	'a:1:{i:0;s:28:\"55_13092021110002_game_0.png\";}',	'55_13092021110002_cover_image.png',	'NULL',	'2021-09-13 11:00:01',	'2021-09-13 11:00:02',	NULL,	1,	NULL),
(56,	'ed8e61de-ee76-492d-a59e-6f9c6f474316',	'TrezeB Bounce',	'TrezeB Bounce is an HTML game.',	'TrezeB Bounce game rule will be published later.',	4,	15,	1,	0,	'a:1:{i:0;s:28:\"56_13092021111535_game_0.png\";}',	'56_13092021111535_cover_image.png',	'NULL',	'2021-09-13 11:15:35',	'2021-09-13 11:15:35',	NULL,	1,	NULL),
(57,	'c4dc64a9-5a1f-4f9b-983f-d51dde2906b8',	'Air Fight',	'Air Fight is an HTML game.',	'Air Fight game rule will be published.',	4,	15,	1,	0,	'a:1:{i:0;s:28:\"57_13092021112141_game_0.png\";}',	'57_13092021112141_cover_image.png',	'NULL',	'2021-09-13 11:21:41',	'2021-09-13 11:21:41',	NULL,	1,	NULL),
(58,	'70465f7c-aab0-40fe-b900-bf0fb44a4865',	'Balloon defense',	'Balloon defense is an HTML game.',	'Balloon defense game rule will be published.',	4,	15,	1,	0,	'a:1:{i:0;s:28:\"58_13092021113016_game_0.png\";}',	'58_13092021113016_cover_image.png',	'NULL',	'2021-09-13 11:30:16',	'2021-09-23 19:03:09',	NULL,	1,	1),
(59,	'1a12d297-a15f-419d-97d0-dd5a434d1959',	'Pinball',	'Pinball is an HTML game.',	'Pinball game rule will be published later.',	8,	20,	1,	0,	'a:1:{i:0;s:28:\"59_13092021113541_game_0.gif\";}',	'59_13092021113541_cover_image.gif',	'NULL',	'2021-09-13 11:35:41',	'2021-09-21 07:50:00',	NULL,	1,	4),
(60,	'81484180-01a4-4d72-8b7b-392b1fcaf251',	'Battleship War',	'Battleship War is an HTML game',	'Battleship War game rule will be published later.',	8,	20,	1,	0,	'a:1:{i:0;s:28:\"60_13092021114010_game_0.jpg\";}',	'60_13092021114010_cover_image.jpg',	'NULL',	'2021-09-13 11:40:09',	'2021-09-13 11:40:10',	NULL,	1,	NULL),
(61,	'5b65a805-7ba1-4073-949c-60f6ed45b956',	'Cake Design',	'Cake Design is an HTML game.',	'Cake Design game rule will be published later',	8,	20,	1,	0,	'a:1:{i:0;s:28:\"61_13092021114413_game_0.jpg\";}',	'61_13092021114413_cover_image.jpg',	'NULL',	'2021-09-13 11:44:13',	'2021-09-21 08:06:09',	NULL,	1,	NULL),
(62,	'd32b0ab7-f1fb-4fb1-9d9d-50fd45c9c3ed',	'Pacman',	'Pacman is an HTML game',	'Pacman game rule will be published later.',	8,	20,	1,	0,	'a:1:{i:0;s:28:\"62_13092021114817_game_0.jpg\";}',	'62_13092021114817_cover_image.jpg',	'NULL',	'2021-09-13 11:48:17',	'2021-09-13 11:48:17',	NULL,	1,	NULL),
(63,	'b872a5c0-c912-4806-815f-dcc3f6e7b4c4',	'Plant Evolution',	'Plant Evolution is an HTML game',	'Plant Evolution game rule will be published later',	8,	20,	1,	1,	'a:1:{i:0;s:28:\"63_13092021115045_game_0.png\";}',	'63_13092021115045_cover_image.png',	'NULL',	'2021-09-13 11:50:45',	'2021-10-20 12:21:20',	NULL,	0,	8),
(64,	'c0f5c06e-74b7-43df-a782-3dab55175aa4',	'Don\'t Crash',	'Don\'t Crash is an HTML game.',	'Don\'t Crash game rule will be published later.',	8,	20,	1,	1,	'a:1:{i:0;s:28:\"64_13092021115523_game_0.png\";}',	'64_13092021115523_cover_image.png',	'NULL',	'2021-09-13 11:55:23',	'2021-10-19 10:34:01',	NULL,	1,	1),
(65,	'c916c190-cf12-498e-ba79-33c271a14005',	'Jumpy Kangaroo',	'Jumpy Kangaroo is an HTML game',	'Jumpy Kangaroo game rule will be published later.',	9,	10,	1,	0,	'a:1:{i:0;s:28:\"65_16092021083039_game_0.jpg\";}',	'65_16092021083039_cover_image.jpg',	'NULL',	'2021-09-16 08:30:38',	'2021-10-19 10:20:06',	NULL,	1,	7),
(66,	'0f950d14-925e-4253-b061-65fea2db535a',	'Jago',	'Jago is an HTML game',	'Jago game rule will be published later.',	9,	10,	1,	0,	'a:1:{i:0;s:28:\"66_16092021083856_game_0.png\";}',	'66_16092021083856_cover_image.png',	'NULL',	'2021-09-16 08:38:56',	'2021-10-20 12:29:44',	NULL,	1,	13),
(67,	'bb300219-282e-424d-9d6a-68cd53c9f3ce',	'Chess Master',	'Chess Master is an HTML game.',	'Chess Master game rule will be published later.',	8,	10,	1,	0,	'a:1:{i:0;s:28:\"67_16092021084846_game_0.png\";}',	'67_16092021084846_cover_image.png',	'NULL',	'2021-09-16 08:48:46',	'2021-09-16 08:48:46',	NULL,	1,	NULL),
(68,	'bd293066-0416-4898-8333-bba18197427f',	'Drip Drop',	'Drip Drop is is an HTML game.',	'Drip Drop game rule will be published later.',	9,	10,	1,	0,	'a:1:{i:0;s:28:\"68_16092021114745_game_0.jpg\";}',	'68_16092021114745_cover_image.jpg',	'NULL',	'2021-09-16 11:47:45',	'2021-10-22 08:26:43',	NULL,	1,	11),
(69,	'6d723807-df97-4b69-9753-174e19da7fd1',	'Ranger vs Zombie',	'Ranger vs Zombie is an HTML game',	'Ranger vs Zombie game rule will be published later.',	7,	10,	1,	0,	'a:1:{i:0;s:28:\"69_16092021120731_game_0.png\";}',	'69_16092021120731_cover_image.png',	'NULL',	'2021-09-16 12:07:31',	'2021-09-16 12:07:31',	NULL,	1,	NULL),
(70,	'e79c9c65-0129-4a90-9f6d-6cb26413835b',	'Stick-man',	'Stick-man is an HTML game.',	'Stick-man game rule will be published later',	9,	10,	1,	0,	'a:1:{i:0;s:28:\"70_16092021133639_game_0.png\";}',	'70_16092021133639_cover_image.png',	'NULL',	'2021-09-16 13:36:39',	'2021-10-20 12:34:07',	NULL,	1,	4),
(71,	'009c2557-4330-4de4-9e4a-5947e9c63cbc',	'Avijit Das',	'sdfgh',	'sdfg',	1,	123456,	1,	0,	'a:1:{i:0;s:28:\"71_24092021115145_game_0.jpg\";}',	'71_24092021115145_cover_image.jpg',	'ASDFGHJK',	'2021-09-24 11:51:45',	'2021-09-24 11:51:45',	NULL,	0,	NULL),
(72,	'05245505-887d-4938-93be-f941a4ca4827',	'hgdsadfg',	'VBFGHJ',	'sdfg',	5,	123456,	1,	0,	'a:1:{i:0;s:28:\"72_24092021115707_game_0.png\";}',	'72_24092021115707_cover_image.jpg',	'ASDFGHJK',	'2021-09-24 11:57:07',	'2021-09-24 11:57:07',	NULL,	0,	NULL),
(73,	'28460c7e-0808-4748-af97-b068ad1ecf47',	'Flappy color birds',	'Flappy color birds is an HTML game',	'Flappy color birds game rule will be published later',	8,	30,	1,	0,	'a:1:{i:0;s:28:\"73_08102021151850_game_0.jpg\";}',	'73_08102021151850_cover_image.jpg',	'NULL',	'2021-10-08 15:18:50',	'2021-10-19 09:28:11',	NULL,	1,	6);

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `languages` (`id`, `name`, `short_code`, `content_type`, `status`, `created_at`, `updated_at`) VALUES
(4,	'English',	'en',	'lang',	1,	'2021-09-21 05:47:12',	'2021-09-24 07:34:34'),
(29,	'Thi',	'thi',	'lang',	1,	'2021-09-23 15:03:07',	'2021-09-23 15:03:07');

DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `post_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` int unsigned NOT NULL,
  `media` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_post_id_index` (`post_id`),
  CONSTRAINT `media_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2020_11_28_193410_create_Admin_table',	1),
(2,	'2020_11_30_183825_create_categories_table',	2),
(3,	'2020_11_28_062425_create_games_table',	3),
(4,	'2020_12_08_113212_banners',	3),
(5,	'2020_12_01_152945_create_competitions_table',	4),
(6,	'2020_12_02_131012_create_prize_table',	4),
(7,	'2020_12_02_141522_create_prizes_table',	4),
(8,	'2020_12_21_140130_add_banner_image_to_competitions',	4),
(9,	'2020_12_09_093410_create_post_table',	5),
(10,	'2020_12_18_061921_add_price_to_Post',	5),
(11,	'2020_12_16_085027_create_media_table',	6),
(12,	'2014_10_12_000000_create_users_table',	7),
(13,	'2014_10_12_100000_create_password_resets_table',	7),
(14,	'2019_08_19_000000_create_failed_jobs_table',	7),
(15,	'2020_12_15_124133_add_is_blocked_to_users',	8),
(16,	'2020_12_15_124431_add_status_to_users',	8),
(17,	'2020_12_15_134431_add_verified_to_users',	8),
(18,	'2020_12_18_063841_add_uuid_to_users_table',	8),
(19,	'2020_12_22_070028_add_msisdn_to_users_table',	8),
(20,	'2020_12_22_071319_create_users_subscribe_status_table',	8),
(21,	'2021_09_15_103017_create_domains_table',	9),
(22,	'2021_09_16_070529_add_is_deleted_to_categories_table',	10),
(23,	'2021_09_16_070529_add_is_deleted_to_competitions_table',	10),
(24,	'2021_09_16_070529_add_is_deleted_to_domains_table',	10);

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uid` int unsigned NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int unsigned NOT NULL,
  `rating` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_home` tinyint(1) NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `application_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application_platform` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_chart` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `price` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_category_id_index` (`category_id`),
  CONSTRAINT `post_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `prizes`;
CREATE TABLE `prizes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reward_text` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int NOT NULL,
  `is_active` int NOT NULL DEFAULT '1',
  `quantity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `reward_types`;
CREATE TABLE `reward_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `sort` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reward_types` (`id`, `name`, `icon`, `status`, `sort`, `created_at`, `updated_at`) VALUES
(1,	'AirTime',	NULL,	1,	NULL,	NULL,	NULL),
(2,	'Voucher',	NULL,	1,	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `rewards`;
CREATE TABLE `rewards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reward_type_id` bigint unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `reward_image` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `banner_image` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `coin` int NOT NULL,
  `is_active` int NOT NULL,
  `date_created` datetime NOT NULL,
  `click_reward` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `rewards` (`id`, `reward_type_id`, `title`, `description`, `reward_image`, `banner_image`, `coin`, `is_active`, `date_created`, `click_reward`, `created_at`, `updated_at`) VALUES
(15,	1,	'Pulsa Rp.5000',	'Tukarkan 150 coin mu dengan pulsa sebesar Rp.5000',	'15_24082021_thumb_image.jpg',	'15_24082021_banner_image.jpg',	150,	1,	'2018-12-26 10:42:19',	4,	NULL,	NULL),
(17,	1,	'Pulsa Rp.50000',	'Tukarkan 460 coin mu dengan pulsa sebesar Rp.50000',	'17_24082021_thumb_image.jpg',	'17_24082021_banner_image.jpg',	460,	1,	'2018-12-26 10:41:47',	4,	NULL,	NULL),
(18,	2,	'Pulsa Rp.100000',	'Tukarkan 620 coin mu dengan pulsa sebesar Rp.100000',	'18_24082021_thumb_image.jpg',	'18_24082021_banner_image.jpg',	620,	1,	'2018-12-26 09:19:17',	1,	NULL,	NULL),
(25,	2,	'Test 074',	'test',	'25_22092021_thumb_image.jpg',	'25_22092021_banner_image.gif',	11,	1,	'2021-09-22 07:56:13',	0,	'2021-09-22 07:56:13',	'2021-09-22 07:56:45');

DROP TABLE IF EXISTS `subscriber`;
CREATE TABLE `subscriber` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `msisdn` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trxid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `recharge_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `subscriber` (`id`, `user_id`, `msisdn`, `package`, `trxid`, `event`, `start_date`, `end_date`, `recharge_date`, `created_at`, `updated_at`) VALUES
(1,	4,	'123456',	'1',	NULL,	NULL,	'2021-09-30 13:35:10',	'2021-10-01 13:35:11',	'2021-10-01 13:35:11',	'2021-09-30 13:35:11',	'2021-09-30 13:35:11'),
(2,	4,	'3123213123213',	'1',	NULL,	NULL,	'2021-10-22 09:38:28',	'2021-10-23 09:38:28',	'2021-10-23 09:38:28',	'2021-10-22 09:38:28',	'2021-10-22 09:38:28');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `msisdn` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_blocked` timestamp NULL DEFAULT NULL,
  `status` timestamp NULL DEFAULT NULL,
  `verified` timestamp NULL DEFAULT NULL,
  `domain` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `uuid`, `msisdn`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `is_blocked`, `status`, `verified`, `domain`) VALUES
(1,	'ced423c7-c511-48af-8b5f-f91fed941328',	'987456312597',	'Test',	'test@test.com',	NULL,	'$2y$10$4MJcWWuF2PleL8.y3T5UMuNoNeleCj8q23wB0i4yDTxtfoxXsdKma',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'home'),
(2,	'7fb39f81-dba3-48e3-88de-e516f70eccca',	'222111',	'O8A4z',	'O8A4z@demo.com',	NULL,	'$2y$10$TZKu4NPjLnifxpeVgxuUcu/xaFO0ILne17JMkRbk.cG2CVX7Nt2/S',	NULL,	'2021-09-24 13:44:11',	'2021-09-24 13:44:11',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(3,	'06e5fdd8-ee70-47c7-916e-643c8a4862a9',	'456789',	'ElLuh',	'ElLuh@demo.com',	NULL,	'$2y$10$XxNSLEr8PTPWj3o.rPk0BubCxZTG4OavA/NakJ/WbNsCykl/DskqO',	NULL,	'2021-09-24 15:27:07',	'2021-09-24 15:27:07',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(4,	'249bf4a8-d50a-4933-9fb4-17b41a27607b',	'sdsadasd',	'cljle',	'cljle@demo.com',	NULL,	'$2y$10$MsJrUid.1n7IJZzILQVzOujaU.Zwd7J5K4SlNrSzA3D/m./JZKoXe',	NULL,	'2021-09-24 15:28:28',	'2021-09-24 15:28:28',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(5,	'e1c6a6d7-d983-467e-b8c1-ea630cbaf6dd',	'96747845889',	'WgAF0',	'WgAF0@demo.com',	NULL,	'$2y$10$rgtRtz9evG0SZz5ZQ9fsWuZmK11SCANbZ6rxpAuBx1kFoglOY7nRm',	NULL,	'2021-09-26 10:55:12',	'2021-09-26 10:55:12',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(6,	'abe6f891-684a-4433-9f3e-8eddf81b4337',	'222111',	'ibHgl',	'ibHgl@demo.com',	NULL,	'$2y$10$gfYl6SJ2bKZfCIle9QqIn.X92k29xNp3wkG6HbS2o0Gm3EAKVm/2u',	NULL,	'2021-09-27 05:04:24',	'2021-09-27 05:04:24',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(7,	'77a3d86f-75a0-4f73-be7a-00cce5f5eea5',	'22211133',	'zxKyV',	'zxKyV@demo.com',	NULL,	'$2y$10$9GoYZfJ1.ORTVhtzy66/5uhLR0LJuQOt3D1LJ4sarEHqN1VBkwQyq',	NULL,	'2021-09-30 05:07:48',	'2021-09-30 05:07:48',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(8,	'07baa97a-46a1-4cd6-a768-628e31ac6875',	'123456',	'im4YO',	'im4YO@demo.com',	NULL,	'$2y$10$FRJ8DZXTwAtYf4EaIRMMjebyr/A29eruq12lRp.bxsQKSfBdtZBpe',	NULL,	'2021-09-30 13:35:11',	'2021-09-30 13:35:11',	NULL,	NULL,	NULL,	'gemezz.code-dev.in'),
(9,	'3498bfc1-0633-4f6a-b481-158567919e38',	'3123213123213',	'CPKbz',	'CPKbz@demo.com',	NULL,	'$2y$10$Xh5DgJaxvvG9MECwA0Vo4e0r7fqBmXZOe0bBM0pH6cu1XvqCQxSoS',	NULL,	'2021-10-22 09:38:28',	'2021-10-22 09:38:28',	NULL,	NULL,	NULL,	'gemezz.code-dev.in');

DROP TABLE IF EXISTS `users_subscribe_status`;
CREATE TABLE `users_subscribe_status` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `package` int NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastcharge` datetime NOT NULL,
  `nextcharge` datetime NOT NULL,
  `token` int NOT NULL,
  `token_status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users_subscribe_status` (`id`, `user_id`, `package`, `status`, `lastcharge`, `nextcharge`, `token`, `token_status`, `created_at`, `updated_at`) VALUES
(2,	'4',	1,	'1',	'2021-09-30 13:35:10',	'2021-10-01 13:35:11',	0,	0,	'2021-09-30 13:35:11',	'2021-09-30 13:35:11'),
(3,	'4',	1,	'1',	'2021-10-22 09:38:28',	'2021-10-23 09:38:28',	0,	0,	'2021-10-22 09:38:28',	'2021-10-22 09:38:28');

DROP TABLE IF EXISTS `winners`;
CREATE TABLE `winners` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `competition_id` bigint NOT NULL,
  `competition_start_date` date NOT NULL,
  `competition_end_date` date NOT NULL,
  `game_uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `date_of_users_played` date NOT NULL,
  `game_score` bigint NOT NULL,
  `position` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prize_image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cron_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2021-10-25 07:12:56
